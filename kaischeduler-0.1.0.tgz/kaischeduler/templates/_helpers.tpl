{{- define "kaischeduler.name" -}}
kaischeduler
{{- end }}

{{- define "kaischeduler.fullname" -}}
{{ include "kaischeduler.name" . }}
{{- end }}
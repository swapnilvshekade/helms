# LiteLLM Helm Chart

A comprehensive Helm chart for deploying LiteLLM - an open-source LLM API Gateway that provides a unified interface to access multiple LLM providers.

## Features

- **Multi-Provider Support**: Access OpenAI, Anthropic, Google, Azure, and more through a single API
- **Easy Deployment**: Deploy LiteLLM with a single Helm command
- **Istio Integration**: Built-in support for VirtualService exposure with Istio
- **Auto-Scaling**: Horizontal Pod Autoscaler support for handling load
- **Health Checks**: Liveness and readiness probes configured
- **Security**: Pod security context and non-root user configuration

## Prerequisites

- Kubernetes 1.20+
- Helm 3.0+
- (Optional) Istio 1.10+ for VirtualService exposure

## Installation

### Basic Installation

```bash
helm install litellm ./litellm -n default
```

### Installation with Custom Values

```bash
helm install litellm ./litellm -n default -f custom-values.yaml
```

### Install in a Specific Namespace

```bash
kubectl create namespace litellm
helm install litellm ./litellm -n litellm
```

## Configuration

### Essential Values

Edit `values.yaml` to configure:

#### 1. API Keys and Environment Variables

```yaml
litellm:
  env:
    OPENAI_API_KEY: "your-openai-key"
    ANTHROPIC_API_KEY: "your-anthropic-key"
    # Add other provider keys as needed
```

#### 2. Replicas

```yaml
replicaCount: 2
```

#### 3. Resource Limits

```yaml
resources:
  limits:
    cpu: 1000m
    memory: 1Gi
  requests:
    cpu: 500m
    memory: 512Mi
```

#### 4. Istio VirtualService

```yaml
istio:
  enabled: true
  virtualservice:
    create: true
    hosts:
      - "litellm.example.com"
    gateways:
      - "default/main-gateway"
```

## Deployment Examples

### Example 1: Basic Deployment with OpenAI

```bash
helm install litellm ./litellm \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  -n default
```

### Example 2: With Istio VirtualService

```bash
helm install litellm ./litellm \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --set istio.enabled=true \
  --set istio.virtualservice.hosts[0]=litellm.dev.example.com \
  --set istio.virtualservice.gateways[0]=istio-system/main-gateway \
  -n default
```

### Example 3: With Auto-Scaling

```bash
helm install litellm ./litellm \
  --set autoscaling.enabled=true \
  --set autoscaling.minReplicas=2 \
  --set autoscaling.maxReplicas=5 \
  -n default
```

## Accessing LiteLLM

### Port Forwarding (ClusterIP Service)

```bash
kubectl port-forward svc/litellm 4000:4000 -n default
# Access at http://localhost:4000
```

### Via Istio VirtualService

If Istio is configured, access through your Istio Ingress Gateway:

```bash
export INGRESS_HOST=$(kubectl get svc -n istio-system istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
curl -H "Host: litellm.example.com" http://$INGRESS_HOST/health
```

### LoadBalancer Service

Change service type in values.yaml:

```yaml
service:
  type: LoadBalancer
```

Then get the external IP:

```bash
kubectl get svc litellm -n default
```

## Testing the Deployment

### Check Deployment Status

```bash
kubectl get deployment litellm -n default
kubectl get pods -n default -l app.kubernetes.io/name=litellm
```

### View Logs

```bash
kubectl logs -n default -l app.kubernetes.io/name=litellm
kubectl logs -n default -l app.kubernetes.io/name=litellm --tail=100 -f
```

### Test Health Endpoint

```bash
kubectl port-forward svc/litellm 4000:4000
curl http://localhost:4000/health
```

## Environment Variables

Common LiteLLM environment variables:

- `OPENAI_API_KEY`: OpenAI API key
- `ANTHROPIC_API_KEY`: Anthropic API key
- `GOOGLE_API_KEY`: Google API key
- `AZURE_API_KEY`: Azure API key
- `COHERE_API_KEY`: Cohere API key
- `DEBUG`: Enable debug logging (true/false)
- `PORT`: Server port (default: 4000)

## Upgrading

```bash
helm upgrade litellm ./litellm -n default
```

## Uninstalling

```bash
helm uninstall litellm -n default
```

## Troubleshooting

### Pod Crashes

```bash
kubectl describe pod <pod-name> -n default
kubectl logs <pod-name> -n default
```

### VirtualService Not Working

1. Verify Istio is installed:
   ```bash
   kubectl get namespace istio-system
   ```

2. Check VirtualService:
   ```bash
   kubectl get virtualservice litellm -n default
   ```

3. Verify Gateway exists:
   ```bash
   kubectl get gateway -n default
   ```

### Memory/CPU Issues

Increase resource limits in values.yaml:

```yaml
resources:
  limits:
    cpu: 2000m
    memory: 2Gi
  requests:
    cpu: 1000m
    memory: 1Gi
```

## Architecture

The chart creates:

- **Deployment**: LiteLLM server pods
- **Service**: ClusterIP service for internal communication
- **VirtualService** (optional): Istio VirtualService for external exposure
- **ServiceAccount**: RBAC service account
- **ConfigMap**: LiteLLM configuration file
- **HPA** (optional): Horizontal Pod Autoscaler for auto-scaling

## Values Reference

See `values.yaml` for all available configuration options.

## Support

For issues related to:
- **LiteLLM**: Visit https://github.com/BerriAI/litellm
- **Helm**: Visit https://helm.sh
- **Kubernetes**: Visit https://kubernetes.io

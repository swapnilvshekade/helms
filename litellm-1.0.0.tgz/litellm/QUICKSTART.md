# LiteLLM Helm Chart - Quick Start Guide

## 1. Prerequisites

Ensure you have:
- A running Kubernetes cluster
- `kubectl` configured to access your cluster
- Helm 3.0+ installed

## 2. Basic Deployment (5 minutes)

### Step 1: Deploy LiteLLM with OpenAI

```bash
cd litellm
helm install litellm . \
  --set litellm.env.OPENAI_API_KEY=sk-YOUR-OPENAI-KEY \
  --namespace default
```

### Step 2: Verify Deployment

```bash
kubectl get pods -l app.kubernetes.io/name=litellm
kubectl get svc litellm
```

### Step 3: Access LiteLLM

```bash
kubectl port-forward svc/litellm 4000:4000
# Now access http://localhost:4000
```

## 3. Istio VirtualService Deployment (with Istio)

If you have Istio installed:

### Step 1: Create Gateway (one-time)

```bash
kubectl apply -f examples/istio-gateway.yaml
```

### Step 2: Deploy with VirtualService

```bash
helm install litellm . \
  --set litellm.env.OPENAI_API_KEY=sk-YOUR-KEY \
  --set istio.enabled=true \
  --set istio.virtualservice.hosts[0]=litellm.example.com \
  --namespace default
```

### Step 3: Verify VirtualService

```bash
kubectl get virtualservice litellm
kubectl describe vs litellm
```

## 4. Common Commands

### View Logs

```bash
kubectl logs -l app.kubernetes.io/name=litellm -f
```

### Update Deployment

```bash
helm upgrade litellm . \
  --set litellm.env.OPENAI_API_KEY=sk-NEW-KEY \
  --namespace default
```

### Delete Deployment

```bash
helm uninstall litellm --namespace default
```

### Check Health

```bash
kubectl port-forward svc/litellm 4000:4000
curl http://localhost:4000/health
```

## 5. Configuration Examples

### Multi-Provider Setup

```bash
helm install litellm . \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --set litellm.env.ANTHROPIC_API_KEY=sk-ant-xxx \
  --set litellm.env.GOOGLE_API_KEY=xxx \
  --namespace default
```

### Production Setup with Auto-Scaling

```bash
helm install litellm . \
  -f examples/values-production.yaml \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --namespace litellm
```

### Development Setup

```bash
helm install litellm . \
  -f examples/values-dev.yaml \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --namespace default
```

## 6. Troubleshooting

### Pod not starting?

```bash
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

### VirtualService not working?

```bash
# Check if Istio is installed
kubectl get namespace istio-system

# Check gateway
kubectl get gateway

# Check virtual service
kubectl describe vs litellm
```

### Connection refused?

```bash
# Verify service is running
kubectl get svc litellm

# Check if port-forward is working
kubectl port-forward svc/litellm 4000:4000 -v=4
```

## 7. Next Steps

- Configure specific models in LiteLLM: See [LiteLLM Documentation](https://docs.litellm.ai/)
- Set up monitoring: Add Prometheus annotations to monitor the deployment
- Configure HTTPS: Use cert-manager for automatic certificate management
- Multi-cluster setup: Deploy to multiple Kubernetes clusters

## 8. API Usage Example

Once deployed and port-forwarded:

```bash
curl http://localhost:4000/models

curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

## Getting Help

- **Chart Issues**: Check README.md for detailed configuration
- **LiteLLM Issues**: Visit https://github.com/BerriAI/litellm
- **Kubernetes Issues**: Visit https://kubernetes.io/docs/

---

Happy deploying! 🚀

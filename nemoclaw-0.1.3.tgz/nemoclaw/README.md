# NemoClaw Helm Chart

This is an umbrella chart for trying NemoClaw on Kubernetes/PCAI with one Helm release. It composes:

- Agent Sandbox controller and CRDs
- NVIDIA OpenShell gateway
- NemoClaw-oriented sandbox image defaults

The chart does not create a namespace. Install it into the namespace you choose:

```sh
helm dependency build ./Nemoclaw/helm/nemoclaw
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace>
```

Namespaced resources are installed into the Helm release namespace. Agent Sandbox CRDs and some RBAC are cluster-scoped.

## Validate

```sh
helm lint ./Nemoclaw/helm/nemoclaw
helm template nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> --debug
```

## First Install Defaults

- `openshell.service.type=ClusterIP`
- `openshell.grpcRoute.enabled=false`
- `openshell.server.sandboxNamespace=""`
- `agentSandbox.namespace.create=false`
- `agentSandbox.controller.extensions=false`

External routing and secrets are disabled by default.

## NemoClaw Agent Images

The chart defaults OpenShell's sandbox image to:

```text
ghcr.io/nvidia/nemoclaw/sandbox-base:latest
```

For Hermes, override:

```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set nemoclaw.agent=hermes \
  --set openshell.server.sandboxImage=ghcr.io/nvidia/nemoclaw/hermes-sandbox-base:latest
```

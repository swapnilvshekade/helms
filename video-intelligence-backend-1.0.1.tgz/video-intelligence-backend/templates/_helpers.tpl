{{- define "vi.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "vi.fullname" -}}
{{- default (printf "%s-%s" .Release.Name .Chart.Name) .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "vi.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ include "vi.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: video-intelligence
{{- end -}}

{{- define "vi.secretName" -}}
{{- default (printf "%s-secrets" .Release.Name) .Values.secrets.name -}}
{{- end -}}

{{/*
Resolve a service image: <repository>:<component>-<tag>.
Args: dict "root" $ "key" <map key> "svc" <service values>
*/}}
{{- define "vi.image" -}}
{{- $img := .root.Values.global.image -}}
{{- $svc := .svc -}}
{{- $key := .key -}}
{{- with .svc.imageFromService -}}
{{- $svc = mergeOverwrite (deepCopy (index $.root.Values.services .)) $svc -}}
{{- $key = . -}}
{{- end -}}
{{- $tag := default (printf "%s-%s" $key $img.tag) $svc.imageTag -}}
{{- printf "%s:%s" (default $img.repository $svc.imageRepository) $tag -}}
{{- end -}}

{{/*
Render an env map into container env entries, evaluating Helm templates inside
the values so URLs stay defined once under `.Values.endpoints`.
Args: dict "root" $ "env" <map>
*/}}
{{- define "vi.env" -}}
{{- $root := .root -}}
{{- range $name, $value := .env }}
- name: {{ $name }}
  {{- if kindIs "map" $value }}
  {{- tpl (toYaml $value) $root | nindent 2 }}
  {{- else }}
  value: {{ tpl (tpl (tpl (tpl (toString $value) $root) $root) $root) $root | quote }}
  {{- end }}
{{- end }}
{{- end -}}

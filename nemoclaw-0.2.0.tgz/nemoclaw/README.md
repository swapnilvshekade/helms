# NemoClaw Helm Chart

This is an umbrella chart for trying NemoClaw on Kubernetes/PCAI with one Helm release. It composes:

- Agent Sandbox controller and CRDs
- NVIDIA OpenShell gateway
- NemoClaw-oriented sandbox image defaults

The chart does not create a namespace. Install it into the namespace you choose:

```sh
helm dependency build ./Nemoclaw/helm/nemoclaw
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace>
```

Namespaced resources are installed into the Helm release namespace. Agent Sandbox CRDs and some RBAC are cluster-scoped.

## Validate

```sh
helm lint ./Nemoclaw/helm/nemoclaw
helm template nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> --debug
```

## First Install Defaults

- `openshell.service.type=ClusterIP`
- `openshell.grpcRoute.enabled=false`
- `openshell.server.sandboxNamespace=""`
- `agentSandbox.namespace.create=false`
- `agentSandbox.controller.extensions=false`

External routing and secrets are disabled by default.

## NemoClaw Agent Images

The chart defaults OpenShell's sandbox image to:

```text
ghcr.io/nvidia/nemoclaw/sandbox-base:latest
```

For Hermes, override:

```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set nemoclaw.agent=hermes \
  --set openshell.server.sandboxImage=ghcr.io/nvidia/nemoclaw/hermes-sandbox-base:latest
```

## Agent Runner Job (optional, in-cluster agent execution)

Run agents directly from the Helm deployment without needing to install the CLI locally. The agent runner is a Kubernetes Job that uses the NVIDIA `openshell` CLI inside the cluster to create sandboxes and execute your chosen agent/tool.

### Prerequisites

1. **Build and push the agent-runner image** (with `openshell` CLI baked in):
```sh
docker build -t <your-registry>/nemoclaw-agent-runner:latest ./agent-runner
docker push <your-registry>/nemoclaw-agent-runner:latest
```

2. **Set credentials** (optional, if your agent needs them):
```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set nemoclaw.inference.createSecret=true \
  --set nemoclaw.inference.secretData.ANTHROPIC_API_KEY="sk-..." \
  --set agentRunner.enabled=true \
  --set agentRunner.image.repository=<your-registry>/nemoclaw-agent-runner
```

3. **Configure the agent command** (what runs inside the sandbox):
```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set agentRunner.enabled=true \
  --set agentRunner.image.repository=<your-registry>/nemoclaw-agent-runner \
  --set 'agentRunner.command={your-tool,arg1,arg2}'
```

Example with Claude Code:
```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set agentRunner.enabled=true \
  --set agentRunner.image.repository=<your-registry>/nemoclaw-agent-runner \
  --set 'agentRunner.command={claude,-p,"Say hello and list files."}'
```

### Re-running the Job

The Job runs once per deployment. To run it again:

```sh
kubectl create job nemoclaw-agent-runner-rerun --from=job/nemoclaw-agent-runner -n <target-namespace>
```

### View Agent Output

```sh
kubectl logs job/nemoclaw-agent-runner -n <target-namespace>
```

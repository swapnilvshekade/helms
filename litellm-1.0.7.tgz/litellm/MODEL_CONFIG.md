# LiteLLM Model Configuration Guide

This guide explains how to configure LLM models in the Helm chart.

## Quick Start

### 1. Basic Configuration in values.yaml

Models are defined under `litellm.models.modelList`:

```yaml
litellm:
  models:
    enabled: true
    modelList:
      - model_name: gpt-3.5-turbo
        litellm_params:
          model: openai/gpt-3.5-turbo
      - model_name: claude-3-sonnet
        litellm_params:
          model: anthropic/claude-3-sonnet-20240229
```

### 2. Set API Keys

```bash
helm install litellm ./litellm \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --set litellm.env.ANTHROPIC_API_KEY=sk-ant-xxx
```

Or in values.yaml:

```yaml
litellm:
  env:
    OPENAI_API_KEY: "sk-xxx"
    ANTHROPIC_API_KEY: "sk-ant-xxx"
```

### 3. Deploy

```bash
helm upgrade litellm ./litellm
```

---

## Supported Providers & Models

### OpenAI

```yaml
- model_name: gpt-3.5-turbo
  litellm_params:
    model: openai/gpt-3.5-turbo

- model_name: gpt-4
  litellm_params:
    model: openai/gpt-4

- model_name: gpt-4-turbo
  litellm_params:
    model: openai/gpt-4-turbo-preview
```

**Environment Variable:**
```yaml
litellm:
  env:
    OPENAI_API_KEY: "sk-your-key"
```

### Anthropic

```yaml
- model_name: claude-3-opus
  litellm_params:
    model: anthropic/claude-3-opus-20240229

- model_name: claude-3-sonnet
  litellm_params:
    model: anthropic/claude-3-sonnet-20240229

- model_name: claude-3-haiku
  litellm_params:
    model: anthropic/claude-3-haiku-20240307
```

**Environment Variable:**
```yaml
litellm:
  env:
    ANTHROPIC_API_KEY: "sk-ant-your-key"
```

### Google Vertex AI

```yaml
- model_name: gemini-pro
  litellm_params:
    model: vertex_ai/gemini-pro

- model_name: gemini-1.5-pro
  litellm_params:
    model: vertex_ai/gemini-1.5-pro
```

**Environment Variable:**
```yaml
litellm:
  env:
    GOOGLE_API_KEY: "your-google-key"
    GOOGLE_PROJECT_ID: "your-project-id"
```

### Azure OpenAI

```yaml
- model_name: azure-gpt-4
  litellm_params:
    model: azure/gpt-4
    api_key: ${AZURE_API_KEY}
    api_base: https://your-resource.openai.azure.com/
    api_version: 2024-02-15-preview
```

**Environment Variable:**
```yaml
litellm:
  env:
    AZURE_API_KEY: "your-azure-key"
    AZURE_API_BASE: "https://your-resource.openai.azure.com/"
```

### Cohere

```yaml
- model_name: command
  litellm_params:
    model: cohere/command

- model_name: command-light
  litellm_params:
    model: cohere/command-light
```

**Environment Variable:**
```yaml
litellm:
  env:
    COHERE_API_KEY: "your-cohere-key"
```

### Ollama (Local)

```yaml
- model_name: llama2
  litellm_params:
    model: ollama/llama2
    api_base: http://ollama:11434
```

---

## Deployment Examples

### Example 1: OpenAI Only

```bash
helm install litellm ./litellm \
  -f examples/values-openai.yaml \
  --set litellm.env.OPENAI_API_KEY=sk-xxx
```

### Example 2: Multi-Provider Setup

```bash
helm install litellm ./litellm \
  -f examples/values-multi-provider.yaml \
  --set litellm.env.OPENAI_API_KEY=sk-xxx \
  --set litellm.env.ANTHROPIC_API_KEY=sk-ant-xxx \
  --set litellm.env.GOOGLE_API_KEY=xxx
```

### Example 3: Anthropic Only

```bash
helm install litellm ./litellm \
  -f examples/values-anthropic.yaml \
  --set litellm.env.ANTHROPIC_API_KEY=sk-ant-xxx
```

---

## Advanced Configuration

### Add Model Aliases

```yaml
litellm:
  models:
    enabled: true
    modelList:
      - model_name: my-gpt-4
        litellm_params:
          model: openai/gpt-4
      
      - model_name: fast-model
        litellm_params:
          model: openai/gpt-3.5-turbo
```

### Custom Model Names

You can alias models to custom names:

```yaml
- model_name: my-claude
  litellm_params:
    model: anthropic/claude-3-opus-20240229
```

Then call via API:
```bash
curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "my-claude",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### Model-Specific Settings

```yaml
- model_name: gpt-4-precise
  litellm_params:
    model: openai/gpt-4
    temperature: 0.2
    top_p: 0.1
    max_tokens: 2048
```

---

## Verify Configuration

### Check Models Available

```bash
kubectl port-forward svc/litellm 4000:4000
curl http://localhost:4000/models
```

### Response Example

```json
{
  "object": "list",
  "data": [
    {
      "id": "gpt-3.5-turbo",
      "object": "model",
      "created": 1234567890,
      "owned_by": "openai"
    },
    {
      "id": "claude-3-sonnet",
      "object": "model",
      "created": 1234567890,
      "owned_by": "anthropic"
    }
  ]
}
```

### Test API Call

```bash
curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo",
    "messages": [
      {
        "role": "user",
        "content": "Say hello!"
      }
    ]
  }'
```

---

## Troubleshooting

### Models Not Loading

Check logs:
```bash
kubectl logs -f litellm-<pod-id>
```

Look for errors like:
- `Model list not initialized` - Check CONFIG_PATH environment variable
- `API key not found` - Ensure API keys are set in environment variables
- `Connection refused` - Check API endpoint connectivity

### API Key Issues

Verify API keys are set:
```bash
kubectl get pod litellm-<pod-id> -o yaml | grep -A 10 env:
```

### Config File Issues

Check ConfigMap:
```bash
kubectl get configmap litellm-config -o yaml
```

---

## Best Practices

1. **Use values files for different environments:**
   - `values-dev.yaml` for development
   - `values-prod.yaml` for production
   - `values-staging.yaml` for staging

2. **Manage secrets separately:**
   ```bash
   kubectl create secret generic litellm-keys \
     --from-literal=OPENAI_API_KEY=sk-xxx \
     --from-literal=ANTHROPIC_API_KEY=sk-ant-xxx
   ```

3. **Start with fewer models and add more gradually**

4. **Test each provider separately before combining**

5. **Monitor model usage and performance:**
   ```bash
   kubectl logs -f litellm-<pod-id> | grep "model:"
   ```

---

## Additional Resources

- [LiteLLM Documentation](https://docs.litellm.ai/)
- [Supported Providers](https://docs.litellm.ai/docs/providers)
- [Model Parameters](https://docs.litellm.ai/docs/completion/input)

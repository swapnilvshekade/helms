# Deploy LiteLLM with OpenAI API Key

This guide shows how to deploy LiteLLM with OpenAI API key configured in the Helm chart.

## Prerequisites

- Kubernetes cluster running
- Helm 3.0+ installed
- OpenAI API key from https://platform.openai.com/api-keys

## Deployment Methods

### Method 1: Using Command Line (Easiest)

Deploy with your OpenAI API key directly:

```bash
helm upgrade litellm ./litellm \
  --set 'litellm.env.OPENAI_API_KEY=sk-your-actual-key-here'
```

Or install fresh:

```bash
helm install litellm ./litellm \
  --set 'litellm.env.OPENAI_API_KEY=sk-your-actual-key-here'
```

### Method 2: Edit values.yaml

1. Open `values.yaml` and update the OpenAI key:

```yaml
litellm:
  env:
    LITELLM_LOCAL_MODEL_COST_MAP: "true"
    OPENAI_API_KEY: "sk-your-actual-key-here"
```

2. Deploy:

```bash
helm upgrade litellm ./litellm
```

### Method 3: Use values-openai.yaml Example

1. Edit `examples/values-openai.yaml`:

```yaml
litellm:
  env:
    LITELLM_LOCAL_MODEL_COST_MAP: "true"
    OPENAI_API_KEY: "sk-your-actual-key-here"
```

2. Deploy:

```bash
helm upgrade litellm ./litellm -f examples/values-openai.yaml
```

---

## After Deployment

### 1. Check Pod Status

```bash
kubectl get pods -l app.kubernetes.io/name=litellm
kubectl describe pod litellm-<pod-id>
```

### 2. View Logs

```bash
kubectl logs -f litellm-<pod-id>
```

### 3. Access LiteLLM

Port forward to access:

```bash
kubectl port-forward svc/litellm 4000:4000
```

Then in another terminal:

```bash
# Check available models
curl http://localhost:4000/models

# Test with GPT-3.5
curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo",
    "messages": [
      {"role": "user", "content": "Say hello!"}
    ]
  }'

# Test with GPT-4
curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [
      {"role": "user", "content": "What is LLM?"}
    ]
  }'
```

---

## Models Available with Default Config

The default `values.yaml` includes these OpenAI models:

- `gpt-3.5-turbo` - Fast, cost-effective
- `gpt-4` - Most capable
- `gpt-4-turbo` - Fast GPT-4 variant

Access them via the API:

```bash
# List all models
curl http://localhost:4000/models

# Use any model in chat completions
curl -X POST http://localhost:4000/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## Verify Configuration

### Check Environment Variables

```bash
kubectl get pod litellm-<pod-id> -o yaml | grep -A 20 "env:"
```

You should see:
```
- name: OPENAI_API_KEY
  value: sk-...
```

### Check Config File

```bash
kubectl get configmap litellm-config -o yaml
```

You should see the model list with OpenAI models.

---

## Troubleshooting

### Models Not Available

```bash
# Check logs for errors
kubectl logs litellm-<pod-id>

# Look for: "MODEL_LIST initialized successfully"
```

### API Key Not Working

```bash
# Verify key is set
kubectl get pod litellm-<pod-id> -o yaml | grep OPENAI_API_KEY

# Check if key starts with 'sk-'
# Get a new key if needed from https://platform.openai.com/api-keys
```

### Connection Errors

```bash
# Check if service is running
kubectl get svc litellm

# Check pod logs
kubectl logs litellm-<pod-id> | grep -i error
```

### 401 Unauthorized

The API key is invalid or expired. Get a new one from https://platform.openai.com/api-keys

---

## Security Best Practices

⚠️ **Warning:** Storing API keys in `values.yaml` or command line is not recommended for production.

### For Production, Use Kubernetes Secrets:

1. **Create a secret:**
```bash
kubectl create secret generic litellm-secrets \
  --from-literal=OPENAI_API_KEY=sk-your-actual-key
```

2. **Reference in values.yaml:**
```yaml
# Instead of env, use valueFrom
envFrom:
  - secretRef:
      name: litellm-secrets
```

3. **Update deployment template** to use `envFrom` instead of `env`

### Alternatively, Use External Secret Management:

- Sealed Secrets
- External Secrets Operator
- HashiCorp Vault
- AWS Secrets Manager

---

## Complete Example Deployment

```bash
#!/bin/bash

# Set your OpenAI API key
OPENAI_KEY="sk-your-actual-key-here"
NAMESPACE="default"

# Deploy LiteLLM with OpenAI
helm upgrade litellm ./litellm \
  --namespace $NAMESPACE \
  --set 'litellm.env.OPENAI_API_KEY='$OPENAI_KEY \
  --set 'replicaCount=1' \
  --set 'istio.enabled=true' \
  --set 'istio.virtualservice.hosts[0]=litellm.example.com'

# Wait for pod to be ready
echo "Waiting for pod to be ready..."
kubectl wait --for=condition=ready pod \
  -l app.kubernetes.io/name=litellm \
  --namespace $NAMESPACE \
  --timeout=300s

# Port forward
echo "Port forwarding..."
kubectl port-forward svc/litellm 4000:4000 --namespace $NAMESPACE &

# Test
echo "Testing LiteLLM..."
sleep 2
curl http://localhost:4000/models
```

Save as `deploy.sh` and run:
```bash
chmod +x deploy.sh
./deploy.sh
```

---

## Clean Up

```bash
helm uninstall litellm --namespace default
```

---

## Next Steps

1. ✅ Deploy with OpenAI key
2. Test all models
3. Add Anthropic/Google keys when needed
4. Move secrets to Kubernetes Secrets for production
5. Configure Istio VirtualService for external access
6. Set up monitoring and logging

---

## Support

- OpenAI API: https://platform.openai.com
- OpenAI Models: https://platform.openai.com/docs/models
- LiteLLM Docs: https://docs.litellm.ai/

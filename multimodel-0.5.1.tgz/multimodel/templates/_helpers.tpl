{{- define "multimodel.name" -}}
multimodel
{{- end }}

{{- define "multimodel.fullname" -}}
{{ include "multimodel.name" . }}
{{- end }}
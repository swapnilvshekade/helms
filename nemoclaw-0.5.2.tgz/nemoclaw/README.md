# NemoClaw Helm Chart

This is a Helm chart for running agents on Kubernetes using NVIDIA OpenShell gateway. It deploys:

- **NVIDIA OpenShell gateway** — gRPC API for agent execution
- **Agent-Runner Job** — runs configured agent commands in-cluster
- **Optional Agent Sandbox controller** — for advanced sandbox management

The chart does not create a namespace. Install it into the namespace you choose:

```sh
helm dependency build ./Nemoclaw/helm/nemoclaw
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace>
```

Everything is configured in `values.yaml` — no CLI flags needed.

Namespaced resources are installed into the Helm release namespace. Agent Sandbox CRDs and some RBAC are cluster-scoped.

## Validate

```sh
helm lint ./Nemoclaw/helm/nemoclaw
helm template nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> --debug
```

## First Install Defaults

- `openshell.service.type=ClusterIP`
- `openshell.grpcRoute.enabled=false`
- `openshell.server.sandboxNamespace=""`
- `agentSandbox.namespace.create=false`
- `agentSandbox.controller.extensions=false`

External routing and secrets are disabled by default.

## NemoClaw Agent Images

The chart defaults OpenShell's sandbox image to:

```text
ghcr.io/nvidia/nemoclaw/sandbox-base:latest
```

For Hermes, override:

```sh
helm upgrade --install nemoclaw ./Nemoclaw/helm/nemoclaw -n <target-namespace> \
  --set nemoclaw.agent=hermes \
  --set openshell.server.sandboxImage=ghcr.io/nvidia/nemoclaw/hermes-sandbox-base:latest
```

## Agent Runner Job (Enabled by Default)

The agent runner automatically creates a Kubernetes Job that runs your configured agent inside the cluster using OpenShell.

### Setup (One-time)

1. **Build and push the agent-runner image**:
```sh
docker build -t quay.io/your-org/nemoclaw-agent-runner:latest ./agent-runner
docker push quay.io/your-org/nemoclaw-agent-runner:latest
```

### Configure in `values.yaml`

Set your credentials and agent command in `values.yaml`:

```yaml
nemoclaw:
  inference:
    createSecret: true
    secretData:
      ANTHROPIC_API_KEY: "sk-your-actual-key"

agentRunner:
  enabled: true
  image:
    repository: "quay.io/your-org/nemoclaw-agent-runner"
    tag: latest
  command:
    - python
    - -m
    - openshell
    - sandbox
    - create
    - --
    - claude
    - -p
    - "Your agent prompt here"
```

### Deploy

```sh
helm dependency build ./helm/nemoclaw
helm upgrade --install nemoclaw ./helm/nemoclaw -n <target-namespace>
```

**Everything is in `values.yaml` — no CLI flags needed.**

### Monitor Job Execution

```sh
# Watch the job run
kubectl logs job/nemoclaw-agent-runner -n <target-namespace> -f
```

## Optional: Enable Agent Sandbox Controller

For advanced sandbox lifecycle management, set in `values.yaml`:

```yaml
agentSandbox:
  enabled: true
```

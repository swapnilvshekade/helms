{{/*
Expand the name of the chart.
*/}}
{{- define "commonai.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "commonai.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "commonai.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "commonai.labels" -}}
helm.sh/chart: {{ include "commonai.chart" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "commonai.name" . }}
{{- with .Values.global.podLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Per-component labels (call with dict "ctx" . "component" "<name>")
*/}}
{{- define "commonai.componentLabels" -}}
{{ include "commonai.labels" .ctx }}
app.kubernetes.io/name: {{ .component }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Per-component pod labels — includes sidecar injection for Istio on PCAI
*/}}
{{- define "commonai.podLabels" -}}
{{ include "commonai.componentLabels" . }}
sidecar.istio.io/inject: "true"
{{- end }}

{{/*
Per-component selector labels
*/}}
{{- define "commonai.selectorLabels" -}}
app.kubernetes.io/name: {{ .component }}
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
{{- end }}

{{/*
Service fullname helper: {{ include "commonai.serviceName" (dict "ctx" . "component" "gateway") }}
*/}}
{{- define "commonai.serviceName" -}}
{{- printf "%s-%s" (include "commonai.fullname" .ctx) .component | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Image tag helper — returns the per-component tag, falling back to global.imageTag
*/}}
{{- define "commonai.imageTag" -}}
{{- .tag | default (.global.imageTag | default "latest") }}
{{- end }}

{{/*
Resolve the Presto Data Copilot backend:
  auto     -> ezpresto on PCAI (ezua VirtualService enabled), else bundled Trino
  bundled  -> in-chart commonai-trino deployment
  ezpresto -> PCAI platform EzPresto (external, HTTPS + Kubernetes SA JWT)
  off      -> Data Copilot SQL disabled
Usage: {{ include "commonai.prestoBackend" . }}
*/}}
{{- define "commonai.prestoBackend" -}}
{{- $b := "auto" -}}
{{- if .Values.presto -}}{{- $b = .Values.presto.backend | default "auto" -}}{{- end -}}
{{- if eq $b "auto" -}}
{{- $ezua := false -}}
{{- if .Values.ezua -}}{{- if .Values.ezua.virtualService -}}{{- $ezua = .Values.ezua.virtualService.enabled -}}{{- end -}}{{- end -}}
{{- if $ezua -}}ezpresto{{- else -}}bundled{{- end -}}
{{- else -}}
{{- $b -}}
{{- end -}}
{{- end }}

{{/*
True when the Data Copilot SQL engine is enabled (bundled or ezpresto).
*/}}
{{- define "commonai.prestoEnabled" -}}
{{- $backend := include "commonai.prestoBackend" . -}}
{{- if or (eq $backend "bundled") (eq $backend "ezpresto") -}}true{{- else -}}false{{- end -}}
{{- end }}

{{/*
Single-knob hostname resolution.

`ezua.virtualService.endpoint` is the ONLY hostname that has to be supplied.
Everything else is derived from it unless explicitly overridden:

  ezua.virtualService.endpoint          <name>.<DOMAIN>        (supplied)
  frontend.externalHost                 <name>.<DOMAIN>        (derived: same host)
  ezua.virtualService.endpointApi       <name>-api.<DOMAIN>    (derived)
  ezua.virtualService.endpointKeycloak  <name>-auth.<DOMAIN>   (derived)

This keeps the Keycloak issuer, the TLS certificate, the OIDC redirect URIs and
the Istio VirtualService hosts in sync, so a rename can never half-apply.
*/}}
{{/* `${DOMAIN_NAME}` is substituted by the PCAI import UI; on a plain `helm install` we resolve it ourselves. */}}
{{- define "commonai.resolveHost" -}}
{{- $h := .host | default "" -}}
{{- if contains "${DOMAIN_NAME}" $h -}}
{{- $d := include "commonai.pcaiDomain" .ctx -}}
{{- if $d -}}{{- replace "${DOMAIN_NAME}" $d $h -}}{{- else -}}{{- $h -}}{{- end -}}
{{- else -}}
{{- $h -}}
{{- end -}}
{{- end }}

{{- define "commonai.endpoint" -}}
{{- $e := .Values.ezua.virtualService.endpoint | default "" -}}
{{- if $e -}}
{{- include "commonai.resolveHost" (dict "ctx" . "host" $e) -}}
{{- else -}}
{{- $d := include "commonai.pcaiDomain" . -}}
{{- if $d -}}{{- printf "%s.%s" (include "commonai.fullname" .) $d -}}{{- end -}}
{{- end -}}
{{- end }}

{{- define "commonai.externalHost" -}}
{{- if .Values.frontend.externalHost -}}
{{- include "commonai.resolveHost" (dict "ctx" . "host" .Values.frontend.externalHost) -}}
{{- else -}}
{{- include "commonai.endpoint" . -}}
{{- end -}}
{{- end }}

{{/*
Discover this PCAI cluster's ingress domain so no hostname has to be supplied.
Prefers a model URL (`<name>.<ns>.serving.<domain>`), then any platform
VirtualService in the release namespace. Empty when the API is unavailable.
*/}}
{{- define "commonai.pcaiDomain" -}}
{{- $domain := "" -}}
{{- $isvcs := lookup "serving.kserve.io/v1beta1" "InferenceService" .Release.Namespace "" -}}
{{- if $isvcs -}}
{{- range $isvc := ($isvcs.items | default list) -}}
{{- if eq $domain "" -}}
{{- $host := regexReplaceAll "(?i)^https?://" (($isvc.status | default dict).url | default "") "" -}}
{{- if regexMatch "\\.serving\\." $host -}}
{{- $domain = regexReplaceAll "^.*\\.serving\\." $host "" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq $domain "" -}}
{{- $routes := lookup "networking.istio.io/v1alpha3" "VirtualService" .Release.Namespace "" -}}
{{- if $routes -}}
{{- range $route := ($routes.items | default list) -}}
{{- if eq $domain "" -}}
{{- range $host := ($route.spec.hosts | default list) -}}
{{- if and (eq $domain "") (contains "." $host) (not (hasSuffix ".svc.cluster.local" $host)) (not (hasPrefix "*" $host)) -}}
{{- $candidate := regexReplaceAll "^[^.]+\\." $host "" -}}
{{- if contains "." $candidate -}}
{{- $domain = $candidate -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $domain -}}
{{- end }}

{{/*
Insert a suffix into the first DNS label of a host.
  host=commonai-aichat.example.com suffix=-auth -> commonai-aichat-auth.example.com
Usage: {{ include "commonai.hostSuffix" (dict "host" $h "suffix" "-auth") }}
*/}}
{{- define "commonai.hostSuffix" -}}
{{- $parts := splitList "." .host -}}
{{- $rest := rest $parts -}}
{{- if $rest -}}
{{- printf "%s%s.%s" (first $parts) .suffix (join "." $rest) -}}
{{- else -}}
{{- printf "%s%s" .host .suffix -}}
{{- end -}}
{{- end }}

{{- define "commonai.endpointApi" -}}
{{- .Values.ezua.virtualService.endpointApi | default (include "commonai.hostSuffix" (dict "host" (include "commonai.externalHost" .) "suffix" "-api")) -}}
{{- end }}

{{- define "commonai.endpointKeycloak" -}}
{{- .Values.ezua.virtualService.endpointKeycloak | default (include "commonai.hostSuffix" (dict "host" (include "commonai.externalHost" .) "suffix" "-auth")) -}}
{{- end }}

{{/*
PCAI platform Keycloak.

The platform Keycloak lives at `keycloak.<DOMAIN>` on the same PCAI domain as the
app, so it is derived from the single hostname knob:
  commonai-aichat.<DOMAIN>  ->  keycloak.<DOMAIN>
Every value can still be overridden explicitly under `externalKeycloak`.
*/}}
{{- define "commonai.pcaiKeycloakHost" -}}
{{- $rest := rest (splitList "." (include "commonai.externalHost" .)) -}}
{{- if $rest -}}{{- printf "keycloak.%s" (join "." $rest) -}}{{- else -}}{{- include "commonai.externalHost" . -}}{{- end -}}
{{- end }}

{{/* Public base URL the browser uses for OIDC (keycloak-js appends /realms/...) */}}
{{- define "commonai.keycloakPublicUrl" -}}
{{- .Values.externalKeycloak.publicUrl | default (printf "https://%s" (include "commonai.pcaiKeycloakHost" .)) -}}
{{- end }}

{{/* In-cluster root of the platform Keycloak (no realm path) */}}
{{- define "commonai.keycloakInternalRoot" -}}
{{- .Values.externalKeycloak.internalRootUrl | default "http://keycloak.keycloak.svc.cluster.local" -}}
{{- end }}

{{/* Issuer MUST match the `iss` claim exactly */}}
{{- define "commonai.keycloakIssuer" -}}
{{- .Values.externalKeycloak.issuer | default (printf "%s/realms/%s" (include "commonai.keycloakPublicUrl" .) .Values.externalKeycloak.realm) -}}
{{- end }}

{{- define "commonai.keycloakJwksUrl" -}}
{{- .Values.externalKeycloak.jwksUrl | default (printf "%s/realms/%s/protocol/openid-connect/certs" (include "commonai.keycloakInternalRoot" .) .Values.externalKeycloak.realm) -}}
{{- end }}

{{/* Realm base used by the gateway (it appends /protocol/openid-connect/...) */}}
{{- define "commonai.keycloakInternalBaseUrl" -}}
{{- .Values.externalKeycloak.internalBaseUrl | default (printf "%s/realms/%s" (include "commonai.keycloakInternalRoot" .) .Values.externalKeycloak.realm) -}}
{{- end }}

{{/*
Fail-fast validation: ensure critical PCAI hostnames are set
*/}}
{{- define "commonai.validateHostnames" -}}
{{- if not (include "commonai.externalHost" .) }}
{{- fail "ERROR: could not discover the PCAI ingress domain; set ezua.virtualService.endpoint (or frontend.externalHost) explicitly" }}
{{- end }}
{{- end }}

{{/*
Default container security context — drop all capabilities, no privilege escalation.
Usage: {{ include "commonai.containerSecurityContext" . | nindent N }}
*/}}
{{- define "commonai.containerSecurityContext" -}}
securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL
{{- end }}

{{/*
Candidate InferenceServices for a role, as "<ns>|<name>|<url>" lines: Ready, with
a URL, name matching `pattern` (or NOT matching when `invert`). Release namespace
first, then every namespace, so an install still works when the models live in
another project.
*/}}
{{- define "commonai.isvcCandidates" -}}
{{- $ctx := .ctx -}}
{{- $pattern := .pattern -}}
{{- $invert := .invert | default false -}}
{{- $out := list -}}
{{- $seen := dict -}}
{{- $scopes := list $ctx.Release.Namespace -}}
{{- if $ctx.Values.mlisTokenRefresh.discoverAllNamespaces -}}
{{- $scopes = append $scopes "" -}}
{{- end -}}
{{- range $scope := $scopes -}}
{{- $list := lookup "serving.kserve.io/v1beta1" "InferenceService" $scope "" -}}
{{- if $list -}}
{{- range $isvc := ($list.items | default list) -}}
{{- $status := $isvc.status | default dict -}}
{{- $url := $status.url | default "" -}}
{{- $ready := false -}}
{{- range $cond := ($status.conditions | default list) -}}
{{- if and (eq (toString $cond.type) "Ready") (eq (toString $cond.status) "True") -}}
{{- $ready = true -}}
{{- end -}}
{{- end -}}
{{- $matches := regexMatch $pattern $isvc.metadata.name -}}
{{- if $invert -}}
{{- $matches = not $matches -}}
{{- end -}}
{{- $key := printf "%s|%s" $isvc.metadata.namespace $isvc.metadata.name -}}
{{- if and $ready $matches (ne $url "") (not (hasKey $seen $key)) -}}
{{- $_ := set $seen $key true -}}
{{- $out = append $out (printf "%s|%s" $key $url) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- join "\n" $out -}}
{{- end }}

{{/*
"true" when an InferenceService is recognisably a text-generation server: its
name matches llmDiscoverPattern, or its predictor runs an LLM engine image /
takes LLM engine flags. Keeps a demo model (image classifier, ...) that happens
to be Ready from being picked as the chat model.
*/}}
{{- define "commonai.isvcLooksLikeLlm" -}}
{{- $ctx := .ctx -}}
{{- $ok := regexMatch ($ctx.Values.mlisTokenRefresh.llmDiscoverPattern | default "(?i)llm") .name -}}
{{- if not $ok -}}
{{- $deployments := lookup "apps/v1" "Deployment" .ns "" -}}
{{- if $deployments -}}
{{- range $deployment := ($deployments.items | default list) -}}
{{- if and (not $ok) (hasPrefix (printf "%s-predictor" $.name) $deployment.metadata.name) -}}
{{- range $container := $deployment.spec.template.spec.containers -}}
{{- if and (not $ok) (eq $container.name "kserve-container") -}}
{{- $blob := printf "%s %s" $container.image (join " " ($container.args | default list)) -}}
{{- if regexMatch "(?i)(vllm|sglang|lmdeploy|text-generation|tgi|tensorrt-llm|trt-llm|llama\\.cpp|ollama|nim/(meta|mistralai|nvidia/llama|nvidia/nemotron|google|microsoft|qwen)|--served-model-name|--max-model-len|--tensor-parallel-size|--chat-template)" $blob -}}
{{- $ok = true -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $ok -}}
{{- end }}

{{/*
Identity of the discovered InferenceService as "<namespace>|<name>|<url>".
For the chat model (`invert` = not an embedder) prefer a candidate that looks
like an LLM server; fall back to the first candidate.
Usage: include "commonai.discoverIsvc" (dict "ctx" . "pattern" "embed" "invert" true)
*/}}
{{- define "commonai.discoverIsvc" -}}
{{- $ctx := .ctx -}}
{{- $found := "" -}}
{{- $cands := splitList "\n" (include "commonai.isvcCandidates" .) -}}
{{- if .invert -}}
{{- range $c := $cands -}}
{{- if and (eq $found "") (ne $c "") -}}
{{- $parts := splitList "|" $c -}}
{{- if eq (include "commonai.isvcLooksLikeLlm" (dict "ctx" $ctx "ns" (index $parts 0) "name" (index $parts 1))) "true" -}}
{{- $found = $c -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq $found "" -}}
{{- range $c := $cands -}}
{{- if and (eq $found "") (ne $c "") -}}
{{- $found = $c -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $found -}}
{{- end }}

{{/* URL of the discovered InferenceService (same selection as commonai.discoverIsvc). */}}
{{- define "commonai.discoverIsvcUrl" -}}
{{- $info := include "commonai.discoverIsvc" . -}}
{{- if $info -}}
{{- index (splitList "|" $info) 2 -}}
{{- end -}}
{{- end }}

{{/* Chat endpoint: explicit value wins, else the discovered LLM InferenceService. */}}
{{- define "commonai.llmEndpoint" -}}
{{- $configured := .Values.llmService.externalLLM.url | default "" -}}
{{- if $configured -}}
{{- $configured -}}
{{- else -}}
{{- include "commonai.discoverIsvcUrl" (dict "ctx" . "pattern" .Values.mlisTokenRefresh.embedDiscoverPattern "invert" true) -}}
{{- end -}}
{{- end }}

{{/* Embedding host without scheme; explicit value wins, else the first ready embedding model. */}}
{{- define "commonai.embedHost" -}}
{{- $configured := "" -}}
{{- if .Values.embeddingService.env -}}
{{- $configured = .Values.embeddingService.env.VLLM_EMBED_HOST | default "" -}}
{{- end -}}
{{- $url := $configured -}}
{{- if not $url -}}
{{- $url = include "commonai.discoverIsvcUrl" (dict "ctx" . "pattern" .Values.mlisTokenRefresh.embedDiscoverPattern "invert" false) -}}
{{- end -}}
{{- regexReplaceAll "(?i)^https?://" $url "" | trimSuffix "/" -}}
{{- end }}

{{/*
Served model id, read from the predictor's `--served-model-name` argument so the
chart does not need the model name configured per cluster.
*/}}
{{- define "commonai.llmModelName" -}}
{{- $explicit := "" -}}
{{- if .Values.llmService.env -}}
{{- $explicit = .Values.llmService.env.MODEL_NAME | default "" -}}
{{- end -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else -}}
{{- $model := "" -}}
{{- $info := include "commonai.discoverIsvc" (dict "ctx" . "pattern" .Values.mlisTokenRefresh.embedDiscoverPattern "invert" true) -}}
{{- if $info -}}
{{- $parts := splitList "|" $info -}}
{{- $namespace := index $parts 0 -}}
{{- $name := index $parts 1 -}}
{{- $deployments := lookup "apps/v1" "Deployment" $namespace "" -}}
{{- if $deployments -}}
{{- range $deployment := ($deployments.items | default list) -}}
{{- if and (eq $model "") (hasPrefix (printf "%s-predictor" $name) $deployment.metadata.name) -}}
{{- range $container := $deployment.spec.template.spec.containers -}}
{{- if and (eq $model "") (eq $container.name "kserve-container") -}}
{{- $blob := replace "=" " " (join " " ($container.args | default list)) -}}
{{- $flag := regexFind "--served-model-name +[^ ]+" $blob -}}
{{- if $flag -}}
{{- $model = last (splitList " " $flag) -}}
{{- else -}}
{{/* vLLM serves under the --model id when --served-model-name is not given */}}
{{- $flag = regexFind "--model +[^ ]+" $blob -}}
{{- if $flag -}}
{{- $model = last (splitList " " $flag) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $model -}}
{{- end -}}
{{- end }}

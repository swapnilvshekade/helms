{{- define "multimodel-deployment.name" -}}
multimodel-deployment
{{- end }}

{{- define "multimodel-deployment.fullname" -}}
{{ include "multimodel-deployment.name" . }}
{{- end }}